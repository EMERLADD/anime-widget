from PIL import Image, ImageDraw, ImageFont, ImageFilter
from dialogue import get_maid_line
import weather_icons
from datetime import datetime, timedelta
from pathlib import Path
import json, random, math

WIDTH, HEIGHT = 1200, 800
BASE = Path.home() / "anime-widget"
CACHE = BASE / "cache"
ASSETS = BASE / "assets"
CACHE.mkdir(parents=True, exist_ok=True)

OUTPUT = CACHE / "widget.png"
WEATHER_CACHE = CACHE / "weather.json"
LOCATION_CACHE = CACHE / "location.json"
CHARACTER = ASSETS / "character.png"
LAYOUT_FILE = BASE / "data" / "layout.json"

DEFAULT_LATITUDE, DEFAULT_LONGITUDE = 31.27, 121.50
DEFAULT_LOCATION = "上海 · 虹口"
CACHE_MINUTES = 30

def font(size, bold=False):
    # Xiaomi HyperOS: confirmed available and supports Chinese.
    # Fail loudly instead of silently falling back to a tiny bitmap font.
    return ImageFont.truetype("/system/fonts/MiSansVF.ttf", size)

F_TIME=font(165,True); F_DATE=font(38,True); F_LOC=font(36,True)
F_TEMP=font(98,True); F_WEATHER=font(44,True); F_SMALL=font(30,True)
F_TINY=font(23); F_BUBBLE=font(38,True)
F_HOUR=font(25,True); F_HOUR_SMALL=font(21,True)

# Centralized positions. A future editor only needs to modify layout.json.
DEFAULT_LAYOUT = {
    "date": {"x": 48, "y": 42},
    "clock": {"x": 48, "y": 118},
    "location": {"x": 50, "y": 315},
    "weather": {"x": 48, "y": 425},
    "forecast": {"x": 48, "y": 655},
    "maid": {"right": 18, "bottom": 6},
    "bubble": {"x1": -100, "y1": -225, "x2": 1430, "y2": 875}
}

def load_layout():
    try:
        user = json.loads(LAYOUT_FILE.read_text(encoding="utf-8"))
    except Exception:
        user = {}
    result = {}
    for name, default in DEFAULT_LAYOUT.items():
        cfg = user.get(name, {}) if isinstance(user, dict) else {}
        result[name] = {k: int(cfg.get(k, v)) for k, v in default.items()}
    return result

LAYOUT = load_layout()

# Weather icons are provided by weather_icons.py (procedural, with an
# asset-override seam). render.py only calls weather_icons.get_weather_icon().

def weather_name(c):
    return {0:"晴",1:"晴间多云",2:"多云",3:"阴",45:"有雾",48:"雾凇",
            51:"小毛毛雨",53:"毛毛雨",55:"较强毛毛雨",61:"小雨",63:"中雨",65:"大雨",
            71:"小雪",73:"中雪",75:"大雪",77:"米雪",80:"阵雨",81:"较强阵雨",82:"强阵雨",
            85:"阵雪",86:"强阵雪",95:"雷雨",96:"雷雨伴冰雹",99:"强雷雨伴冰雹"}.get(c,"天气未知")

def read_cache():
    try:
        return json.loads(WEATHER_CACHE.read_text(encoding="utf-8"))
    except Exception:
        return None

def get_weather():
    # V8.3 render layer never performs slow I/O.
    # update_data.py owns location + geocoding + Open-Meteo.
    cached=read_cache()
    if cached:
        return cached
    return {
        "temperature":"--","feels_like":"--","humidity":"--","weather_code":-1,
        "wind_speed":"--","is_day":1,"max":"--","min":"--",
        "latitude":DEFAULT_LATITUDE,"longitude":DEFAULT_LONGITUDE,
        "location":DEFAULT_LOCATION,"hourly":[],
        "updated":datetime.now().isoformat()
    }

w=get_weather(); LOCATION=w.get("location",DEFAULT_LOCATION); now=datetime.now(); code=w["weather_code"]
condition=weather_name(code)
weekday=["星期一","星期二","星期三","星期四","星期五","星期六","星期日"][now.weekday()]
night=not bool(w.get("is_day",1))
rainy=code in {51,53,55,56,57,61,63,65,66,67,80,81,82,95,96,99}
snowy=code in {71,73,75,77,85,86}
rng=random.Random(now.strftime("%Y%m%d%H"))

# ---- bright anime sky background ----
if night: top,bottom=(35,48,104),(84,75,145)
elif rainy: top,bottom=(92,143,183),(159,190,213)
else: top,bottom=(72,164,242),(174,220,250)

img=Image.new("RGBA",(WIDTH,HEIGHT),(0,0,0,255)); draw=ImageDraw.Draw(img)
for y in range(HEIGHT):
    t=y/HEIGHT
    rgb=tuple(int(top[i]+(bottom[i]-top[i])*t) for i in range(3))
    draw.line((0,y,WIDTH,y),fill=(*rgb,255))

# soft clouds on a separate blurred layer
cloud=Image.new("RGBA",(WIDTH,HEIGHT),(0,0,0,0)); cd=ImageDraw.Draw(cloud)
for cx,cy,s in [(120,90,1.0),(390,50,.8),(820,110,1.0),(1080,230,.75),(520,660,.55)]:
    if rainy: col=(220,230,240,90)
    else: col=(255,255,255,105)
    for ox,oy,r in [(-55,10,55),(0,-5,72),(60,12,52),(15,30,75)]:
        rr=int(r*s); x=int(cx+ox*s); y=int(cy+oy*s)
        cd.ellipse((x-rr,y-rr,x+rr,y+rr),fill=col)
cloud=cloud.filter(ImageFilter.GaussianBlur(14)); img.alpha_composite(cloud); draw=ImageDraw.Draw(img)

# weather atmosphere
if night:
    for _ in range(28):
        x=rng.randrange(WIDTH); y=rng.randrange(240); r=rng.choice([1,1,2])
        draw.ellipse((x-r,y-r,x+r,y+r),fill=(255,250,225,150))
    draw.ellipse((1050,45,1150,145),fill=(255,246,200,190))
elif rainy:
    for _ in range(45):
        x=rng.randrange(WIDTH); y=rng.randrange(HEIGHT)
        draw.line((x,y,x-5,y+18),fill=(225,242,255,95),width=2)
elif snowy:
    for _ in range(36):
        x=rng.randrange(WIDTH); y=rng.randrange(HEIGHT); r=rng.randint(2,4)
        draw.ellipse((x-r,y-r,x+r,y+r),fill=(255,255,255,150))

# border
draw.rounded_rectangle((14,14,1186,786),radius=42,outline=(225,245,255,145),width=3)

# helper pill/card
def rounded(box,r=24,fill=(25,90,170,145),outline=(225,245,255,120),width=2):
    draw.rounded_rectangle(box,radius=r,fill=fill,outline=outline,width=width)

def centered_text(box, text, fnt, fill="white", stroke_width=0, stroke_fill=None):
    x1,y1,x2,y2=box
    bb=draw.textbbox((0,0),text,font=fnt,stroke_width=stroke_width)
    tw=bb[2]-bb[0]; th=bb[3]-bb[1]
    x=x1+(x2-x1-tw)//2
    y=y1+(y2-y1-th)//2-bb[1]
    kw={"font":fnt,"fill":fill}
    if stroke_width:
        kw["stroke_width"]=stroke_width
        kw["stroke_fill"]=stroke_fill
    draw.text((x,y),text,**kw)

# date pill
DATE_X,DATE_Y=LAYOUT["date"]["x"],LAYOUT["date"]["y"]
rounded((DATE_X,DATE_Y,DATE_X+452,DATE_Y+70),26,(20,88,174,165))
centered_text((DATE_X,DATE_Y,DATE_X+452,DATE_Y+70),f"{now:%Y / %m / %d}  ·  {weekday}",F_DATE,"white")

# time with navy soft stroke
CLOCK_X,CLOCK_Y=LAYOUT["clock"]["x"],LAYOUT["clock"]["y"]
draw.text((CLOCK_X,CLOCK_Y),now.strftime("%H:%M"),font=F_TIME,fill=(250,252,255),
          stroke_width=5,stroke_fill=(25,60,135))

# location pill — two-line live location, kept clear of the character
parts=LOCATION.split(" · ",1)
if len(parts)==2:
    loc_city,loc_district=parts
else:
    loc_city,loc_district=LOCATION,""

LOC_X1,LOC_Y1=LAYOUT["location"]["x"],LAYOUT["location"]["y"]
LOC_X2,LOC_Y2=LOC_X1+340,LOC_Y1+95
rounded((LOC_X1,LOC_Y1,LOC_X2,LOC_Y2),27,(20,88,174,165))

if loc_district:
    # City on the first line, district/county on the second.
    centered_text((LOC_X1+12,LOC_Y1+8,LOC_X2-12,LOC_Y1+48),
                  f"●  {loc_city}",F_LOC,"white")
    centered_text((LOC_X1+12,LOC_Y1+48,LOC_X2-12,LOC_Y2-7),
                  loc_district,F_LOC,"white")
else:
    centered_text((LOC_X1+12,LOC_Y1,LOC_X2-12,LOC_Y2),
                  f"●  {loc_city}",F_LOC,"white")

# weather card
WX,WY=LAYOUT["weather"]["x"],LAYOUT["weather"]["y"]
rounded((WX,WY,WX+562,WY+225),36,(55,116,192,128))
draw.text((WX+27,WY+23),f"{w['temperature']}°",font=F_TEMP,fill=(255,255,255),
          stroke_width=2,stroke_fill=(30,74,150))
main_icon = weather_icons.get_weather_icon(w["weather_code"], 64, night)
if main_icon:
    img.alpha_composite(main_icon, (WX+270, WY+28))
    condition_x = WX+342
else:
    condition_x = WX+282
draw.text((condition_x,WY+37),condition,font=F_WEATHER,fill="white")
draw.text((WX+284,WY+105),f"体感 {w['feels_like']}°",font=F_SMALL,fill=(235,246,255))

# next 3 hours forecast — three larger cards
future=w.get("hourly",[])
if future:
    FC_X1,FC_Y1=LAYOUT["forecast"]["x"],LAYOUT["forecast"]["y"]
    CARD_W=210
    CARD_H=118
    GAP=16

    for i,item in enumerate(future[:3]):
        x1=FC_X1+i*(CARD_W+GAP)
        y1=FC_Y1
        x2=x1+CARD_W
        y2=y1+CARD_H

        rounded((x1,y1,x2,y2),22,(35,100,175,135),width=1)

        centered_text((x1,y1+8,x2,y1+38),
                      item["time"],F_HOUR_SMALL,(245,250,255))
        centered_text((x1,y1+40,x2,y1+76),
                      f"{weather_name(item['weather_code'])}  {item['temperature']}°",
                      F_HOUR_SMALL,(245,250,255))
        centered_text((x1,y1+78,x2,y2-5),
                      f"降水概率：{item['rain_probability']}%",
                      F_TINY,(235,247,255))

# bottom-left area reserved for future chat UI

# dialogue decision is decoupled into dialogue.py
line = get_maid_line(w, now, BASE / "dialogue")

# character on lower-right
if CHARACTER.exists():
    char=Image.open(CHARACTER).convert("RGBA")
    target_h=600
    sc=target_h/char.height
    char=char.resize((int(char.width*sc),target_h),Image.Resampling.LANCZOS)
    maid_right=LAYOUT["maid"]["right"]; maid_bottom=LAYOUT["maid"]["bottom"]
    img.alpha_composite(char,(WIDTH-char.width-maid_right,HEIGHT-char.height-maid_bottom))
    draw=ImageDraw.Draw(img)

# Dynamic dialogue inside DeepSeek.png's native thought bubble.
# Coordinates are tuned for the current 1200x500 composition.
bubble_cfg=LAYOUT["bubble"]
TB_X1,TB_Y1,TB_X2,TB_Y2=bubble_cfg["x1"],bubble_cfg["y1"],bubble_cfg["x2"],bubble_cfg["y2"]

def wrap_bubble_text(s, fnt, max_width, max_lines=2):
    # Explicit \n always wins, so contextual dialogue stays two lines.
    manual = s.split("\\n")
    if len(manual) > 1:
        return manual[:max_lines]

    lines = []
    cur = ""
    for ch in s:
        test = cur + ch
        bb = draw.textbbox((0, 0), test, font=fnt)
        if bb[2] - bb[0] <= max_width:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines[:max_lines]

bubble_lines = wrap_bubble_text(line, F_BUBBLE, TB_X2 - TB_X1 - 55, 2)
line_gap = 10
heights = []
for ln in bubble_lines:
    bb = draw.textbbox((0, 0), ln, font=F_BUBBLE)
    heights.append(bb[3] - bb[1])

total_h = sum(heights) + line_gap * max(0, len(bubble_lines) - 1)
yy = TB_Y1 + (TB_Y2 - TB_Y1 - total_h) // 2

for ln, lh in zip(bubble_lines, heights):
    bb = draw.textbbox((0, 0), ln, font=F_BUBBLE)
    tw = bb[2] - bb[0]
    x = TB_X1 + (TB_X2 - TB_X1 - tw) // 2
    draw.text(
        (x, yy - bb[1]),
        ln,
        font=F_BUBBLE,
        fill=(27, 55, 119, 255),
    )
    yy += lh + line_gap

# tiny update stamp
try: stamp=datetime.fromisoformat(w["updated"]).strftime("%H:%M")
except: stamp="--:--"
draw.text((WX+287,WY+160),f"更新 {stamp}",font=F_TINY,fill=(235,247,255,210))

img.convert("RGB").save(OUTPUT,"PNG",optimize=True)
print("Rendered:",OUTPUT)
print(f"{LOCATION} | {w['temperature']}° {condition} | 体感 {w['feels_like']}°")
